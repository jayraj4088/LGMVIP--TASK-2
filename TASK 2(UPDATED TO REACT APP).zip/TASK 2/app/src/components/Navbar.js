import React from 'react';
import LGMlogo from './LGMlogo.jpg';


export default function Navbar(props) {


    return (
        <div className="navbar">
           <div className="brand">
             <img src={LGMlogo}/>
           </div>
           <ul className="nav-links">
             <li><button onClick={()=>{ props.handleClick(true);}} className="btn">BOLLYSHOP TEAM</button></li>
           </ul>           
        </div>
    )
}